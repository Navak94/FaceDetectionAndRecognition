﻿//using System.Random;

namespace FaceDetectionAndRecognition

{


    public partial class Form1
    {
        public class DictationGrammar : System.Speech.Recognition.Grammar
        {
        };
         
    }

}